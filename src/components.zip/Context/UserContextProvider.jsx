import React, { createContext, useState, useContext, useEffect } from 'react'
import API_ENDPOINTS from '../config/apiConfig';

const UserContext = createContext();

export const UserContextProvider = ({ children }) => {
  const [isAuthenticate, SetisAuthenticate] = useState(null)
  const [loading, setLoading] = useState(false)


  // console.log("api url", API_ENDPOINTS.PROTECTED)


 useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch(API_ENDPOINTS.PROTECTED, {
          credentials: "include",
        });

        SetisAuthenticate(res.ok);
      } catch {
        SetisAuthenticate(false);
      }
    };

    checkAuth();
  }, []);


   if (isAuthenticate === null) return null;



  return (
    <UserContext.Provider value={{ isAuthenticate, loading }}>
      {
        children
      }
    </UserContext.Provider>

  )
}


export const useAuth = () => {
  return useContext(UserContext);
};

