
 import { Plus } from "lucide-react";
const Dash = ()=>{

    return (

        <div>

            <div className="w-auto h-[95vh]  ml-10">
            
            <div className="flex">
            <div className="bg-white hover:text-white hover:bg-blue-500 text-blue-400  py-1 border-2 border-blue-200 px-4 rounded flex items-center just">
                <Plus size={18} strokeWidth={3} />
                <button className="ml-2 text-lg">Income</button>
            </div>
            
          

        </div>

            </div>

            
        </div>
    )
}

export default Dash;