import React from 'react'

const Paymentsuccess = () => {
  return (
    <div>
      
      <div className='flex items-center justify-center'>
        <h1>Payment Successfully</h1>
      </div>
    </div>
  )
}

export default Paymentsuccess
